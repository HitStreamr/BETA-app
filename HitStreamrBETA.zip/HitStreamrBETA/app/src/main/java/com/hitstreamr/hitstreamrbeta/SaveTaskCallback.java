package com.hitstreamr.hitstreamrbeta;

public interface SaveTaskCallback {
    void goBack();
}
