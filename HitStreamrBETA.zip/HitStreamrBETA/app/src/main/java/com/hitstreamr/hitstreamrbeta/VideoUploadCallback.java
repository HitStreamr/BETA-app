package com.hitstreamr.hitstreamrbeta;

public interface VideoUploadCallback {
    public void unbindUploadService();
    void goBack();
}